from django.urls import path

from . import views

urlpatterns = [
    path('', views.StoreLoginList.as_view(), name='book_list'),
    path('view/<int:pk>', views.StoreLoginView.as_view(), name='book_view'),
    path('new', views.StoreLoginCreate.as_view(), name='book_new'),
    path('view/<int:pk>', views.StoreLoginView.as_view(), name='book_view'),
    path('edit/<int:pk>', views.StoreLoginUpdate.as_view(), name='book_edit'),
    path('delete/<int:pk>', views.StoreLoginDelete().as_view(), name='book_delete'),
]