from django.contrib import admin
from comhavenapp.models import StoreLogin
# Register your models here.

admin.site.register(StoreLogin)