from django.conf.urls import url
from django.contrib import admin
from comhavenapp import views as core_views
from django.contrib.auth import views as auth
from django.contrib.auth.decorators import login_required
from django.urls import path

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', core_views.index, name='home'),
    url(r'^comhavenapp$', core_views.index, name='home'),
    url(r'^order/(?P<order_id>\d+)/$', core_views.show, name='show'),
    url(r'^order/new/$', core_views.new, name='new'),
    url(r'^order/edit/(?P<order_id>\d+)/$', core_views.edit, name='edit'),
    url(r'^order/delete/(?P<order_id>\d+)/$', core_views.destroy, name='delete'),
    url(r'^users/login/$', auth.LoginView.as_view(template_name="login.html"), name='login'),
    url(r'^users/logout/$', auth.LogoutView.as_view(), name='logout'),
    url(r'^signup/$', core_views.signup, name='signup'),
    #url(r'^users/change_password/$', login_required(auth.password_change), {'post_change_redirect' : '/','template_name': 'change_password.html'}, name='change_password'),


]
